# My new AI project

This project is gonna be Awe5ome
I will NOT tell you any secrets ^a1x3a3xa7xa
Server Deployment Key:
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACD3qO4fXAM2M/qjKwItnYGwzEzmJmrr81s/c/i7Snft7QAAAKBvyAzYb8gM
2AAAAAtzc2gtZWQyNTUxOQAAACD3qO4fXAM2M/qjKwItnYGwzEzmJmrr81s/c/i7Snft7Q
AAAECnvgkUMjPgbkFeknsJictxOsymaMuRrp1tj0hzo3vnRfeo7h9cAzYz+qMrAi2dgbDM
TOYmauvzWz9z+LtKd+3tAAAAGFVpVEhhY2syNS1haUBleGFtcGxlLmNvbQECAwQF
-----END OPENSSH PRIVATE KEY-----

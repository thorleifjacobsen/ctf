require('dotenv').config()

console.log("The flag is: "+process.env.flag)
import os
from encryption import ascon_AEAD128_encrypt, ascon_AEAD128_decrypt
from secrets import randbelow

def encrypt():
    key1 = randbelow(2**128)
    key2 = randbelow(2**128)
    ad = input("Your Associated data: ").encode()
    pt = input("Your Plaintext: ").encode()
    flag_info = b"The flag is here"
    flag = os.environ.get("FLAG", "wack{demo_flag_just_for_testing}").encode()
    if ad == flag_info:
        print("Sorry, that would be to easy")
        return
    ct1, t1 = ascon_AEAD128_encrypt(key1, key2, ad, pt)
    ct2, t2 = ascon_AEAD128_encrypt(key1, key2, flag_info, flag)
    print(f"Your ciphertext: {ct1.hex()}")
    print(f"Your tag: {t1.hex()}")
    print(f"The encrypted flag: {ct2.hex()}")
    print(f"The flag tag: {t2.hex()}")

def decrypt():
    key1 = randbelow(2**128)
    key2 = randbelow(2**128)
    ad = input("Your acociated_data: ").encode()
    ct = bytes.fromhex(input("Your ciphertext: "))
    t = bytes.fromhex(input("Your tag: "))
    if b"The flag is here" in ad:
        print("Sorry, that would be to easy")
        return
    pt, valid = ascon_AEAD128_decrypt(key1, key2, ad, ct, t)
    print(pt)
    print(valid)
    if not valid:
        print("The message did not have a valid tag")
        return
    print(f"The decrypted plaintext: {pt.decode()}")


if __name__ == "__main__":
    text1 = "Welcome to my ascon implementation test server"
    text2 = "Can you find an error that allows you to recover the flag?"
    lpadding = (len(text2)-len(text1)) // 2
    rpadding = (len(text2)-len(text1)) // 2 + ((len(text2)-len(text1)) % 2)
    print( "+ " + "-"*len(text2) + " +")
    print( "| " + " " * lpadding + text1 + " " * rpadding + "|")
    print( "| " + text2 + " |")
    print( "+ " + "-"*len(text2) + " +")
    while(True):
        print("What do you want to do?")
        print("1) Encrypt or 2) Decrypt")
        choice = input("> ")
        match choice:
            case "1":
                encrypt()
            case "2":
                decrypt()
            case _:
                print("That is not a valid option")


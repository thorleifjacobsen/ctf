# The following is a modified implementation of the Ascon-based Lightweight Cryptography Standards for constrained Devices
# Standarized in NIST Special Publication 800 NIST SP 800-232


### Static variables
const = [0x3c, 0x2d, 0x1e, 0xf, 0xf0, 0xe1, 0xd2, 0xc3, 0xb4, 0xa5, 0x96, 0x87, 0x78, 0x69, 0x5a, 0x4b]
sbox = [0x4, 0xb, 0x1f, 0x14, 0x1a, 0x15, 0x9, 0x2, 0x1b, 0x5, 0x8, 0x12, 0x1d, 0x3, 0x6, 0x1c, 0x1e, 0x13, 0x7, 0xe, 0x0, 0xd, 0x11, 0x18, 0x10, 0xc, 0x1, 0x19,0x16,0xa, 0xf, 0x17]
rotr1 = [19, 61, 1, 10, 7]
rotr2 = [28, 39, 6, 17, 41]
IV = 0x00001000808c0001

### Auxiliary Functions
def bytes_to_bin(b):
    return [int(bin(b[i])[2:].rjust(8,"0")[j]) for i in range(len(b)) for j in range(8)]

def parse(X, r):
    if len(X) % r != 0:
        return [X[i:i+r] for i in range(0, len(X), r)]
    return [X[i:i+r] for i in range(0, len(X), r)] + [[]]

def pad(X, r):
    j = (-len(X) - 1) % r
    L = r - (j + 1)
    return X + [1] + [0]*j, L

def format(X):
    return [int("".join(str(xi) for xi in x), 2) for x in X]

def rotr(X, i):
    return (X >> i) | ((X & (pow(2, i)-1)) << (64-i))

def back_to_bytes(X, r):
    return b"".join(e.to_bytes(r//8, byteorder="big") for e in X)

### The substitution permutatuion network

def P_c(S, rnd, i):
    a = [i for i in S]
    a[2] ^= const[16 - rnd + i]
    return a

def P_s(S):
    a = [sum(((S[j] >> i) & 1) << j for j in range(5)) for i in range(64)]
    b = [sbox[a_i] for a_i in a]
    c = [sum(((b[i] >> j) & 1) << i for i in range(64)) for j in range(5)]
    return c

def P_l(S):
    return [s ^ rotr(s, r1) ^ rotr(s, r2) for s, r1, r2 in zip(S, rotr1, rotr2)]

def ascon_p(S, rnd):
    state = [s for s in S]
    for i in range(rnd):
        state = P_l(P_s(P_c(state, rnd, i)))
    return state

### AEAD Parts

def initialization(key, nonce):
    S = [IV, key >> 64, key & (pow(2, 64) - 1), nonce >> 64, nonce & (pow(2, 64) - 1)]
    S = ascon_p(S, 12)
    x = [None, None, 0, key >> 64, key & (pow(2, 64) - 1)]
    for i in range(2, 5):
        S[i] ^= x[i]
    return S

def associated_data(S, a_d):
    if not a_d:
        S[-1] ^= 1
        return S
    a_d = bytes_to_bin(a_d)
    a = parse(a_d, 128)
    a[-1], _ = pad(a[-1], 128)
    a = format(a)
    state = S
    for a_i in a:
        x = [a_i >> 64, a_i & (pow(2, 64) - 1), None, None, None]
        for i in range(2):
            state[i] ^= x[i]
        state = ascon_p(state, 8)
    state[-1] ^= 1
    return state

def plaintext(S, pt):
    pt = bytes_to_bin(pt)
    ct = []
    p = parse(pt, 128)
    p[-1], L = pad(p[-1], 128)
    p = format(p)
    state = S
    for p_i in p[:-1]:
        x = [p_i >> 64, p_i & (pow(2, 64) - 1), None, None, None]
        for i in range(2):
            state[i] ^= x[i]
        ct.append(state[0] << 64 | state[1])
        state = ascon_p(state, 8)
    x = [p[-1] >> 64, p[-1] & (pow(2, 64) - 1), None, None, None]
    for i in range(2):
        state[i] ^= x[i]
    ct.append((state[0] << 64 | state[1]) >> 128 - L)
    return state, ct, L

def ciphertext(S, ct):
    ct = bytes_to_bin(ct)
    pt = []
    c = parse(ct, 128)
    c[-1], L = pad(c[-1], 128)
    c = format(c)
    state = S
    for c_i in c[:-1]:
        x = [c_i >> 64, c_i & (pow(2, 64) - 1), None, None, None]
        pt.append((state[0] << 64 | state[1]) ^ c_i)
        for i in range(2):
            state[i] = x[i]
        state = ascon_p(state, 8)
    ks = (state[0] << 64 | state[1]) 
    unpadded_ct = c[-1] >> (128 - L)
    pt.append(ks >> (128 - L) ^ unpadded_ct)
    ct_padding = c[-1] & (pow(2, 128-L) - 1)
    ks_padding = ks & (pow(2, 128-L) - 1)
    s_padding = ct_padding ^ ks_padding
    last_state = (unpadded_ct << 128-L) | s_padding
    x = [last_state >> 64, last_state & (pow(2, 64) - 1), None, None, None]
    for i in range(2):
        state[i] = x[i]
    return state, pt, L

def finalization(S):
    s = S
    S = ascon_p(s, 12)
    tag = (S[0] << (64 * 4) | S[1] << (64 * 3) | S[2] << (64 * 2) | S[3] << 64 | S[4])
    return tag



### Encryption

def ascon_AEAD128_encrypt(key, nonce, a_d, pt):
    S = initialization(key, nonce)
    S = associated_data(S, a_d)
    S, ct, L = plaintext(S, pt)
    t = finalization(S)
    return back_to_bytes(ct[:-1], 128) + ct[-1].to_bytes(L//8, byteorder="big"), t.to_bytes(320//8, byteorder="big")

### Decryption

def ascon_AEAD128_decrypt(key, nonce, a_d, ct, t):
    S = initialization(key, nonce)
    S = associated_data(S, a_d)
    S, pt, L = ciphertext(S, ct)
    t_prime = finalization(S)
    return back_to_bytes(pt[:-1], 128) + pt[-1].to_bytes(L//8, byteorder="big"), t_prime.to_bytes(320//8, byteorder="big") == t

if __name__ == "__main__":
    import random
    for i in range(2**10):
        key1 = random.randint(0, 2**128-1)
        key2 = random.randint(0, 2**128-1)
        data = random.randbytes(random.randint(0, 512))
        a_d = random.randbytes(random.randint(0, 512))
        ct, t = ascon_AEAD128_encrypt(key1, key2, a_d, data)
        pt, v = ascon_AEAD128_decrypt(key1, key2, a_d, ct, t)
        assert data == pt
        assert v

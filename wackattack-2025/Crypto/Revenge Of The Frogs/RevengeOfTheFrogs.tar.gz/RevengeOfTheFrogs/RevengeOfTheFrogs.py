from sage.all import *
from hashlib import sha256
from bitarray import bitarray
from time import time
from math import log2
import os

f, r, o, g  = 2, 75, 45, 30

flag = os.environ.get("FLAG", "wack{demo_flag_just_for_testing}")

def upper_diagonal(K, M):
    n = M.ncols()
    for i in range(n):
        for j in range(i+1,n):
            M[i,j] += M[j,i]
            M[j,i] = K(0) 

def Frogkeygen(f,r,o,g):
    K = GF(f)

    Frogspawn = [];
    for _ in range(o-g):
        Frog_Egg  = Matrix(K,r,r)
        for i in range(r-o):
            for j in range(i,r-g):
                Frog_Egg[i,j] = K.random_element()
        Frogspawn.append(Frog_Egg)
    for _ in range(g):
        Frog_Egg  = Matrix(K,r,r)
        for i in range(r-g):
            for j in range(i,r):
                Frog_Egg[i,j] = K.random_element()
        Frogspawn.append(Frog_Egg)

    Pond = Matrix(K,o,o)
    while not Pond.is_invertible():
        Pond = Matrix(K,[ [K.random_element() for _ in range(o)] for _ in range(o)] )

    Creek = Matrix(K,r,r)
    while not Creek.is_invertible():
        Creek = Matrix(K,[ [K.random_element() for _ in range(r)] for _ in range(r)] )

    Tadpole_Key = [ Creek.transpose()*M*Creek for M in Frogspawn ]

    Toad_Key = []
    for i in range(o):
        Toad_leg = Matrix(K,r,r)
        for j in range(o):
            Toad_leg += Pond[i,j]*Tadpole_Key[j]
        upper_diagonal(K, Toad_leg)
        Toad_Key.append(Toad_leg)


    basis_r = (K**r).basis()
    basis_o = (K**o).basis()

    Anoures_key = Creek.inverse() * Matrix(K, [ basis_r[i] for i in range(r-o,r) ] ).transpose()
    Anura_Key = Creek.inverse() * Matrix(K, [ basis_r[i] for i in range(r-g,r) ] ).transpose()
    Frog_Key =  Pond * Matrix(K, [ basis_o[i] for i in range(o-g,o) ] ).transpose()

    return Toad_Key, Anura_Key, Anoures_key, Frog_Key

def verify_signature(f, o, PK, message, signature):
    K = GF(f)
    d = int(log2(f))
    bits = bitarray()
    bits.frombytes(sha256(message.encode()).digest())
    bit_vector = vector(K, (K.from_integer(i) for i in bits[:d*o]))

    return vector([ signature*M*signature for M in PK]) == bit_vector


if __name__ == "__main__":
    PK, _, _, _ = Frogkeygen(f, r, o, g)
    K = GF(f)
    key_time = time()
    print("Welcome to the Frog command server, only frogs may enter commands")
    print("Start of Public Key")
    for i, M in enumerate(PK):
        print(f"Matrix {i}")
        for R in M:
            print(",".join(str(i) for i in R))
    print("End of Public Key")
    while True:
        command = input("Command: ").split()
        signature = input("Signature: ")
        signature = vector(K, [K.from_integer(int(i, 16)) for i in signature.split(":")])
        if (time() - key_time > 60*20):
            print("Sorry public key expired")
            exit()
        if not verify_signature(f, o, PK, " ".join(command), signature):
            print("That is not a valid signature")
            continue
        if command[0] == "echo":
            print(" ".join(command[1:]))
        elif " ".join(command) == "ping":
            print("pong")
        elif " ".join(command) == "getflag":
            print(flag)
        else:
            print("Invalid command")



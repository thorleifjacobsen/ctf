from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from secrets import token_bytes
import os

key1 = token_bytes(16)
key2 = token_bytes(16)
flag = os.environ.get("FLAG", "wack{this_is_a_demo_flag}")

def encrypt(pt):
    iv1 = token_bytes(16)
    iv2 = token_bytes(16)
    cipher1 = AES.new(key1, AES.MODE_CBC, iv=iv1)
    cipher2 = AES.new(key2, AES.MODE_CBC, iv=iv2)
    pt_padded = pad(pt, AES.block_size)
    temp = cipher1.encrypt(pt_padded)
    ct = cipher2.encrypt(temp)
    return iv1 + iv2 + ct

def decrypt(ct):
    iv1, ct = ct[:16], ct[16:]
    iv2, ct = ct[:16], ct[16:]
    cipher1 = AES.new(key1, AES.MODE_CBC, iv=iv1)
    cipher2 = AES.new(key2, AES.MODE_CBC, iv=iv2)
    temp = cipher2.decrypt(ct)
    pt_padded = cipher1.decrypt(temp)
    pt = unpad(pt_padded, AES.block_size)
    return pt

if __name__ == "__main__":
    message = "Welcome to the CBCBC code server"
    print("=" * len(message))
    print(message)
    print("=" * len(message))
    print(f"here is a flag for connecting: {encrypt(flag.encode()).hex()}")
    while True:
        print("Input an encrypted command")
        enc_command = input("> ")
        try:
            command = decrypt(bytes.fromhex(enc_command))
            if command.split(b" ")[0] == b"echo":
                print(" ".join(command.decode().split(" ")[1:]))
            elif command.split(b" ")[0] == b"ping":
                print("pong")
            elif command.split(b" ")[0] == b"ls":
                print("".join(os.listdir('.')))
            else:
                print("Invalid command")
        except:
            pass


from fastecdsa.curve import P256
from secrets import randbelow
from Crypto.Util.number import bytes_to_long, long_to_bytes
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import os


def segment(b, n):
    l = len(b) // n
    return [bytes_to_long(b[i:i+l]) for i in range(0, len(b), l)]

secret = randbelow(2**256)
hidden = randbelow(2**128)
FLAG = os.environ.get("FLAG", "wack{demo_flag}")

class Randomizer:

    def __init__(self, seed):
        r = randbelow(2**256)
        self.Q = P256.G * r
        self.P = self.Q * secret
        self.state = (self.P * seed).x

    def _updatestate(self):
        self.state = (self.P * self.state).x

    def random(self):
        out = (self.Q * self.state).x
        self._updatestate()
        return out

    def get_public_parameters(self):
        return self.P, self.Q

    def randombytes(self,n):
        k = n // 32
        r = n % 32
        out = b"".join(long_to_bytes(self.random()).rjust(32, b"\x00") for _ in range(k))
        if r != 0:
            out += long_to_bytes(self.random() % 2**(r*8)).rjust(r, b"\x00")
        return out

R = Randomizer(randbelow(2**256))

def get_flag():
    c = AES.new(R.randombytes(16), AES.MODE_ECB)
    f = c.encrypt(pad(FLAG.encode(), AES.block_size))
    return f.hex()

while True:
    print("Welcome the agency secure flag server")
    print("What do you want to do. (1) Get info, (2) Get random, (3) get flag or (4) get public parameters")
    i = input("> ")
    match i:
        case "1":
            a = randbelow(2**256)
            b = (hidden << 128) | randbelow(2**128)
            c = randbelow(2**256)
            d = (pow(b,-1, P256.q)*(a+c*secret) % P256.q)
            print(f"Here are some hints\n{a=}\nb=?\n{c=}\n{d=}")
        case "2":
            print(f"Random value = {R.random()}")
        case "3":
            print(f"Flag = {get_flag()}")
        case "4":
            P, Q = R.get_public_parameters()
            print(f"P = {P}\nQ = {Q}")
        case _:
            print("Not a valid option")


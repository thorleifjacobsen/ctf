from Crypto.Util.number import bytes_to_long, long_to_bytes, inverse
from Crypto.PublicKey.ECC import EccPoint
from Crypto.PublicKey._nist_ecc import p521_curve
from cryptography.hazmat.primitives.serialization import load_ssh_private_key

FLAG = bytes_to_long(open("../flag.txt","rb").read())

# calculate y point given x using the weierstrass equation: y^2 = x^3 + a*x + b
def lift_x(x): return pow((x**3 + a*x + b)%p, (p+3)//4, p)

# NIST-p521 curve
a = -3
b = int(p521_curve().b)
p = int(p521_curve().p)
order = int(p521_curve().order)

# using SSH private key as ECC secret
key = load_ssh_private_key(open("/root/.ssh/id_ecdsa","rb").read(),b"")
d = key.private_numbers().private_value

# load the flag as x-point on a curve, find y-point by lifting x and then encrypt the point using our secret
P = EccPoint(FLAG, lift_x(FLAG), "p521")
Q = P*d
print(f"Q={hex(Q.x)},{hex(Q.y)}")
const express = require('express')
const app = express()
const port = 3000

const hemmeligPin = Array(100).fill(0).map(() => Math.floor(Math.random() * 10).toString()).join('')

app.get('/', (req, res) => {
  const pin = req.query.pin
  if (pin == undefined) {
    res.send("Gi en pinkode ved å bruke for eksempel <a href='/?pin=1234'>?pin=1234</a>")
    return
  }
  if (pin.length > hemmeligPin.length) {
    res.send("Pin er for lang")
    return
  }
  var distanse = 0
  for (var i = 0; i < pin.length; i++) {
    if (pin[i] > '9' || pin[i] < '0') {
      res.send("Pin skal kun være siffer")
      return
    }
    distanse += Math.abs(parseInt(pin[i]) - parseInt(hemmeligPin[i]))
  }
  if (distanse > 0){
    res.send(`Pinkoden var feil, med en distanse på ${distanse}`)
    return
  }
  if (pin.length != hemmeligPin.length) {
    res.send("Alle de gitte sifrene var korrekte, men pinkoden har feil lengde")
    return
  }
  res.send(`Gratulerer, du har funnet pinkoden! Her er flagget: ${process.env.FLAGG}`)
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

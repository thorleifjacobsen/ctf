import { Hono } from "hono";
import { html } from "hono/html";
import { adminReview } from "./bot";
import { v4 as uuid } from "uuid";
import { serveStatic } from "hono/bun";

const app = new Hono();

const FLAG = process.env.FLAG || "wack{dummy}";

const letters = new Map();

app.get("/", serveStatic({path: "src/static/index.html"}))

app.post("/", async (c) => {
  const data = await c.req.formData();

  const name = data.get("name");
  const message = data.get("message");
  const id = uuid();

  if (letters.has(id)) return c.redirect("/")

  letters.set(id, { name, message });
  return c.redirect(`/${id}`);
});

app.get("/:letterId", (c) => {
  const letterId = c.req.param("letterId");

  const letter = letters.get(letterId);
  if (!letter) return c.text("No letter with that id");
  return c.html(html`
      <html>
      <head>
        <title>Love letter | WackCTF</title>
      </head>
      <body>
      <main>
      <section>
        <h1>Love letter from ${letter.name}</h1>
        <p>${letter.message} </p>
        <img src="/static/love.png" alt=${letter.name}>
       </section>
      </body>
      </main>
    </html>
  `);
});

app.use(
  "/static/*",
  serveStatic({
    root: "./src",
  })
);

app.post("/review/:letterId", async (c) => {
  const letterId = c.req.param("letterId");

  await adminReview(c, letterId, FLAG);

  return c.text("Thanks for reviewing the letter!");
});

export default app;

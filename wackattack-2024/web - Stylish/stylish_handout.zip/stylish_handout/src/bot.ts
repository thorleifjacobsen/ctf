import type { Context } from "hono";
import { sign } from "hono/jwt";
import puppeteer from "puppeteer";

export async function adminReview(
  c: Context,
  user_id: string,
  FLAG: string,
  secret: string
) {
  let browser;
  try {
    browser = await puppeteer.launch({
      headless: true,
      pipe: true,
      args: ["--no-sandbox", "--disable-gpu", "--disable-setuid-sandbox"],
      dumpio: true,
    });
    const cookie = await sign({ user_id: FLAG }, secret);

    const page = await browser.newPage();

    await page.setCookie({
      name: "session",
      value: cookie,
      path: "/",
      domain: "localhost",
      httpOnly: true,
    });

    const url = `http://localhost:3000?q=${user_id}`;
    await page.goto(url, {
      waitUntil: "networkidle0",
      timeout: 60_000,
    });

    await new Promise((resolve) => setTimeout(resolve, 4000));
  } catch (e) {
    console.error(e);
    return c.text("Error...");
  }
  await browser.close();
}

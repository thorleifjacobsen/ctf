import { Hono } from "hono";
import { html } from "hono/html";
import { v4 as uuid } from "uuid";
import { getCookie, setCookie } from "hono/cookie";
import { decode, sign, verify } from "hono/jwt";
import { serveStatic } from "hono/bun";
import { adminReview } from "./bot";

const app = new Hono();

var styles = new Map();

const secret = uuid() + uuid();
const FLAG = process.env.FLAG || "wack{dummy}";

app.use("/*", async (c, next) => {
  const userSession = (await getCookie(c, "session")) || "";
  try {
    await verify(userSession, secret);
  } catch (e) {
    await setCookie(c, "session", await sign({ user_id: uuid() }, secret), {
      httpOnly: true,
      secure: true,
    });
    return c.redirect("/");
  }
  await next();
});

app.get("/", async (c) => {
  const cookie = await getCookie(c, "session");
  const session = await decode(cookie as string);

  const query = c.req.query("q")

  let userStyle = styles.get(session.payload.user_id);
  if (query) userStyle = styles.get(query);

  return c.html(html`
    <html>
      <head>
        <title>Stylish | WackCTF</title>
        <link rel="stylesheet" href="/static/style.css" />
        <style>
          ${userStyle}
        </style>
        <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            max-width: 800px;
            margin: 10px auto;
          }
        </style>
      </head>
      <body>
        <h1>Style the Wack™️!</h1>
        <p>I would love to see the cool styling you come up with! Please send me a <b>post</b> when you have something cool!</p>

        <div
          class="box"
          src="/static/wack.png"
          alt="The WackAttack Logo ™️©️❤️"
        ></div>

        <form method="post" action="/style">
          <textarea id="${session.payload.user_id}" name="style" rows="20" cols="90">${userStyle}</textarea>
          <br />
          <button>Update styling</button>
        </form>
      </body>
    </html>
  `);
});

app.post("/style", async (c) => {
  const sessionEnc = await getCookie(c, "session");
  const session = await decode(sessionEnc as string);

  const body = await c.req.formData();
  const style = body.get("style");

  styles.set(session.payload.user_id, style);

  return c.redirect("/");
});


app.post("/review", async (c) => {
  const sessionEnc = await getCookie(c, "session");
  const session = await decode(sessionEnc as string);

  await adminReview(c, session.payload.user_id, FLAG, secret);

  return c.text("Admin looked at your styling and nods approvingly\n");
});

app.use(
  "/static/*",
  serveStatic({
    root: "./src",
  })
);

export default app;

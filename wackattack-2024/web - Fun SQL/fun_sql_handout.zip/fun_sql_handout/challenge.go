package main

import (
	"database/sql"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"
	"strings"

	_ "github.com/mattn/go-sqlite3"
)

var dbpath = "./database.db"
var FLAG = os.Getenv("FLAG")

func init() {
	os.Remove(dbpath)
	os.Create(dbpath)
	db, err := sql.Open("sqlite3", dbpath)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	db.Exec("create table notes (data text, public integer)")

	if err != nil {
		log.Fatal(err)
	}

	db.Exec("insert into notes(data,public) values(?,?)", FLAG, 0)
	db.Exec("insert into notes(data,public) values(?,?)", "Hello world", 1)
	db.Exec("insert into notes(data,public) values(?,?)", "Day in a life of a CTF player", 1)
	db.Exec("insert into notes(data,public) values(?,?)", "Web is the best!", 1)

	if err != nil {
		log.Fatal(err)
	}
}

func handleGetNotes() func(http.ResponseWriter, *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		db, err := sql.Open("sqlite3", fmt.Sprintf("file:%s?mode=ro", dbpath))
		if err != nil {
			log.Fatal(err)
		}
		defer db.Close()

		var textSearch = "%" + r.URL.Query().Get("text") + "%"

		textSearch = strings.Replace(textSearch, "'", "''", len(textSearch)/2)

		rows, err := db.Query(fmt.Sprintf("SELECT data FROM notes WHERE public = 1 AND data LIKE '%s'", textSearch))
		if err != nil {
			log.Fatalln(err)
			http.Error(w, "Failed to query database", http.StatusInternalServerError)
			return
		}
		defer rows.Close()

		var notes []string
		for rows.Next() {
			var note string
			if err := rows.Scan(&note); err != nil {
				http.Error(w, "Failed to scan row", http.StatusInternalServerError)
				return
			}
			notes = append(notes, note)
		}

		if err := rows.Err(); err != nil {
			http.Error(w, "Error iterating over rows", http.StatusInternalServerError)
			return
		}

		tmpl := `
            <h1>Notes</h1>
            <ul>
                {{range .}}
                    <li>{{.}}</li>
                {{end}}
            </ul>
        `

		t, err := template.New("notes").Parse(tmpl)
		if err != nil {
			http.Error(w, "Failed to parse template", http.StatusInternalServerError)
			return
		}

		if err := t.Execute(w, notes); err != nil {
			http.Error(w, "Failed to execute template", http.StatusInternalServerError)
		}
	}
}

func main() {
	mux := http.NewServeMux()

	mux.HandleFunc("/", handleGetNotes())

	port := ":1337"
	fmt.Printf("Starting server on port %s\n", port)
	if err := http.ListenAndServe(port, mux); err != nil {
		log.Fatalf("Server failed to start: %v", err)
	}
}

package main

import (
	"database/sql"
	"fmt"
	"html"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"text/template"

	"github.com/google/uuid"
	_ "github.com/mattn/go-sqlite3"
)

var dbpath = "./database.db"
var FLAG = os.Getenv("FLAG")

func AddNote(note Note) error {
	db, _ := sql.Open("sqlite3", dbpath)
	defer db.Close()

	_, err := db.Exec("INSERT INTO notes (id, data) VALUES (?, ?)", note.Id, note.Data)
	if err != nil {
		return err
	}

	return nil
}

func GetNote(noteId string) (*Note, error) {
	db, _ := sql.Open("sqlite3", dbpath)
	defer db.Close()

	var note Note
	query := "SELECT id, data FROM notes WHERE id = ?"
	err := db.QueryRow(query, noteId).Scan(&note.Id, &note.Data)
	if err != nil {
		return nil, err
	}

	return &note, nil
}

type Note struct {
	Id   uuid.UUID
	Data string
}

func NewNote(data string) Note {
	return Note{
		Id:   uuid.New(),
		Data: data,
	}
}

func init() {
	os.Remove(dbpath)
	os.Create(dbpath)
	db, err := sql.Open("sqlite3", dbpath)
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	db.Exec("create table notes (id text, data text)")
}

func handleGetNote(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Security-Policy", "default-src 'self';")

	noteId := r.PathValue("noteId")

	note, err := GetNote(noteId)

	if err != nil {
		http.Error(w, "Note does not exists", http.StatusInternalServerError)
		return
	}

	t, err := template.New("note").Parse(note.Data)
	if err != nil {
		http.Error(w, "Failed to parse note template", http.StatusInternalServerError)
		return
	}

	if err := t.ExecuteTemplate(w, "note", &note); err != nil {
		http.Error(w, "Failed to execute template", http.StatusInternalServerError)
	}
}

func handleCreateNote(w http.ResponseWriter, r *http.Request) {
	data := r.FormValue("data")

	data = html.EscapeString(data)

	note := NewNote(data)

	err := AddNote(note)

	if err != nil {
		http.Error(w, "Failed to create note", http.StatusInternalServerError)
		return
	}

	http.Redirect(w, r, "/notes/"+note.Id.String(), http.StatusSeeOther)
}

func serveStaticFile(file string) func(w http.ResponseWriter, r *http.Request) {
	return func(w http.ResponseWriter, r *http.Request) {
		http.ServeFile(w, r, fmt.Sprintf("./static/%s", file))
	}
}

func main() {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /notes/{noteId}", handleGetNote)
	mux.HandleFunc("POST /notes", handleCreateNote)

	mux.HandleFunc("GET /report", serveStaticFile("report.html"))
	mux.HandleFunc("GET /{$}", serveStaticFile("note.html"))

	mux.HandleFunc("POST /adminvisit/{noteId}", handleAdminViewNote)
	mux.HandleFunc("GET /admin/flag", handleAdminGetFlag)

	port := ":1337"
	fmt.Printf("Starting server on port %s\n", port)
	if err := http.ListenAndServe(port, mux); err != nil {
		log.Fatalf("Server failed to start: %v", err)
	}
}

func handleAdminViewNote(w http.ResponseWriter, r *http.Request) {
	nodeId := r.PathValue("noteId")

	uuidRegex, err := uuid.Parse(nodeId)

	if err != nil {
		http.Error(w, "Please use a valid noteId", http.StatusInternalServerError)
		return
	}

	cmd := exec.Command("bun", "bot.ts", "--noteId", uuidRegex.String())
	err = cmd.Run()
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	w.Write([]byte("Admin visited your note"))
}

func handleAdminGetFlag(w http.ResponseWriter, r *http.Request) {
	remoteAddr := r.RemoteAddr
	ip, _, err := net.SplitHostPort(remoteAddr)
	if err != nil {
		http.Error(w, "Invalid remote address", http.StatusInternalServerError)
		return
	}
	if ip == "127.0.0.1" || ip == "::1" {
		w.Write([]byte(FLAG))
	} else {
		w.Write([]byte("REVENGE! ONLY ADMIN CAN SEE FLAG NOW"))
	}
}

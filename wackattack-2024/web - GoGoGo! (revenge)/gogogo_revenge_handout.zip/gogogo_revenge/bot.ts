import puppeteer from 'puppeteer';
import { parseArgs } from "util";

const { values } = parseArgs({
    args: process.argv.slice(2),
    options: {
        noteId: {
            type: 'string',
        },
    },
    strict: true,
    allowPositionals: true,
});

const noteId = values.noteId;

if (!noteId) {
    console.error('Usage: node bot.js --noteId <noteId>');
    process.exit(1);
}

(async () => {
    const browser = await puppeteer.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox', "--js-flags=--noexpose_wasm,--jitless"],
    });

    const page = await browser.newPage();

    try {
        // Visit user note
        await page.goto(`http://127.0.0.1:1337/notes/${noteId}`, {  waitUntil: 'networkidle0', timeout: 60_000 }); 

        // Wait for 2 seconds
        await new Promise(function(resolve) { 
            setTimeout(resolve, 2000)
        });

        console.log('Puppeteer script executed successfully.');
    } catch (error) {
        console.error('Error running Puppeteer script:', error);
        process.exit(1);
    } finally {
        await browser.close();
    }
})();
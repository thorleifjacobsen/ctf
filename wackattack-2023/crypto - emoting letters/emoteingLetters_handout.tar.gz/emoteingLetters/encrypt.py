from Crypto.Util.number import bytes_to_long, long_to_bytes
from secret import flag
import string,random

initial_emoji = "😀".encode()

letters = [i for i in string.ascii_letters]

random.shuffle(letters)

ct = ""

for b in flag:
    if b in string.ascii_letters:
        ct += long_to_bytes(bytes_to_long(initial_emoji) + letters.index(b)).decode()
    else:
        ct += b
print(f"ct = \"{ct}\"")


/* Masks for grpf in GrpfStillTracking */
#define FSTILLTRACKING  1
#define FESCAPE         2
#define FTOP            4
#define FBOTTOM         8
#define FKEYBOARD       16

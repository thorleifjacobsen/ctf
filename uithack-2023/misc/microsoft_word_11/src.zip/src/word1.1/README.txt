FUK paper, lets use computers to write!

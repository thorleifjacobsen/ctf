/* wwdlg.h

	contains the id definitions of the standard windows control.

*/

#define IDOK         1
#define IDCANCEL     2
#define IDABORT      3
#define IDRETRY      4
#define IDIGNORE     5
#define IDYES        6
#define IDNO         7

/* This is the WINDOWS.H for the p-code Opus */

#define NOMINMAX
#include "qwindows.h"   /* The standard p-code windows.h */
#include "toolbox.h"    /* Our toolbox */
